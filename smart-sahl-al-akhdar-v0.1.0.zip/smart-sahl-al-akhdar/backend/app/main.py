from fastapi import FastAPI

from backend.app.api.routes.correspondence import router as correspondence_router
from backend.app.core.config import settings

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Academic prototype for intelligent district administration.",
    version=settings.VERSION,
)

app.include_router(correspondence_router, prefix="/api/v1")


@app.get("/", tags=["System"])
def home() -> dict[str, str]:
    return {
        "project": settings.PROJECT_NAME,
        "description": "Intelligent District Management System",
        "status": "running",
        "version": settings.VERSION,
    }


@app.get("/health", tags=["System"])
def health_check() -> dict[str, str]:
    return {"status": "healthy"}
