# Smart Sahl Al-Akhdar
**Intelligent District Management System** — Academic MVP foundation.

## Current scope
- FastAPI backend
- Health and project information endpoints
- Initial correspondence module (incoming/outgoing)
- In-memory demo storage (data resets when the server restarts)
- Automated API tests

> This is an academic prototype. Use synthetic data only. Do not enter real citizen records,
> official correspondence, identity documents, or confidential government information.

## Requirements
- Python 3.11 or newer
- Windows 11
- Visual Studio Code

## Windows setup
Open this folder in VS Code, then open **Terminal → New Terminal**.

Create and activate a virtual environment:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt in VS Code instead:

```cmd
.venv\Scripts\activate.bat
```

Install dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Run the API from the project root:

```powershell
uvicorn backend.app.main:app --reload
```

Open:
- API documentation: http://127.0.0.1:8000/docs
- Health check: http://127.0.0.1:8000/health
- Project information: http://127.0.0.1:8000/

## Run tests
```powershell
python -m pytest
```

## First API examples
Create a demo incoming letter in `/docs` using `POST /api/v1/correspondence`:

```json
{
  "reference_number": "DEMO-IN-001",
  "direction": "incoming",
  "subject": "Demo maintenance request",
  "sender": "Synthetic Department",
  "recipient": "District Administration",
  "document_date": "2026-11-10",
  "notes": "Synthetic example only"
}
```

List records with `GET /api/v1/correspondence`.

## Important engineering notes
- The current repository uses temporary in-memory storage. It is not durable and is not suitable for official use.
- Authentication, authorization, audit logging, secure document storage, PostgreSQL migrations,
  backups, and deployment hardening are not implemented yet.
- AI suggestions must remain advisory. Administrative, legal, and financial decisions require
  authorized human review.
