# Architecture — v0.1.0

The first iteration is a **modular monolith**:
- `api/routes`: HTTP endpoints
- `schemas`: request/response validation
- `services`: application logic
- `core`: project-wide settings

The correspondence service currently stores records in process memory solely to make
the first API demonstrable without requiring PostgreSQL. The next persistence milestone
will introduce SQLAlchemy, PostgreSQL, migrations, and repository-level tests.
