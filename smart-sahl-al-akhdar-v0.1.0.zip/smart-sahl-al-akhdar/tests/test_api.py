from fastapi.testclient import TestClient

from backend.app.main import app

client = TestClient(app)


def test_home_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["project"] == "Smart Sahl Al-Akhdar"


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}


def test_create_and_list_correspondence():
    payload = {
        "reference_number": "TEST-IN-001",
        "direction": "incoming",
        "subject": "Test maintenance request",
        "sender": "Synthetic Department",
        "recipient": "District Administration",
        "document_date": "2026-11-10",
        "notes": "Synthetic test data only",
    }
    created = client.post("/api/v1/correspondence", json=payload)
    assert created.status_code == 201
    assert created.json()["reference_number"] == "TEST-IN-001"

    listed = client.get("/api/v1/correspondence")
    assert listed.status_code == 200
    assert any(item["reference_number"] == "TEST-IN-001" for item in listed.json())


def test_missing_correspondence_returns_404():
    response = client.get("/api/v1/correspondence/999999")
    assert response.status_code == 404
