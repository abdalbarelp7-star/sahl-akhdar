from fastapi import APIRouter, HTTPException, status

from backend.app.schemas.correspondence import (
    CorrespondenceCreate,
    CorrespondenceRead,
)
from backend.app.services.correspondence_service import correspondence_service

router = APIRouter(prefix="/correspondence", tags=["Correspondence"])


@router.post(
    "",
    response_model=CorrespondenceRead,
    status_code=status.HTTP_201_CREATED,
    summary="Create a correspondence record",
)
def create_correspondence(payload: CorrespondenceCreate) -> CorrespondenceRead:
    return correspondence_service.create(payload)


@router.get(
    "",
    response_model=list[CorrespondenceRead],
    summary="List correspondence records",
)
def list_correspondence() -> list[CorrespondenceRead]:
    return correspondence_service.list_all()


@router.get(
    "/{correspondence_id}",
    response_model=CorrespondenceRead,
    summary="Get a correspondence record",
)
def get_correspondence(correspondence_id: int) -> CorrespondenceRead:
    record = correspondence_service.get(correspondence_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Correspondence record not found")
    return record
