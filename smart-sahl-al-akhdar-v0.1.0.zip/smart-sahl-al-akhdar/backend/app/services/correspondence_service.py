from datetime import datetime, timezone

from backend.app.schemas.correspondence import (
    CorrespondenceCreate,
    CorrespondenceRead,
)


class CorrespondenceService:
    """Temporary in-memory service; replace with a database repository later."""

    def __init__(self) -> None:
        self._records: dict[int, CorrespondenceRead] = {}
        self._next_id = 1

    def create(self, payload: CorrespondenceCreate) -> CorrespondenceRead:
        record = CorrespondenceRead(
            id=self._next_id,
            **payload.model_dump(),
            created_at=datetime.now(timezone.utc),
        )
        self._records[self._next_id] = record
        self._next_id += 1
        return record

    def list_all(self) -> list[CorrespondenceRead]:
        return list(self._records.values())

    def get(self, record_id: int) -> CorrespondenceRead | None:
        return self._records.get(record_id)


correspondence_service = CorrespondenceService()
