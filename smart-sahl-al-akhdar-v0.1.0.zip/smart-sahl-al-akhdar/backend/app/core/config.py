class Settings:
    PROJECT_NAME = "Smart Sahl Al-Akhdar"
    VERSION = "0.1.0"


settings = Settings()
