from datetime import date, datetime, timezone
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class CorrespondenceDirection(str, Enum):
    INCOMING = "incoming"
    OUTGOING = "outgoing"


class CorrespondenceCreate(BaseModel):
    reference_number: str = Field(min_length=2, max_length=50)
    direction: CorrespondenceDirection
    subject: str = Field(min_length=3, max_length=250)
    sender: str = Field(min_length=2, max_length=150)
    recipient: str = Field(min_length=2, max_length=150)
    document_date: date
    notes: str | None = Field(default=None, max_length=2000)


class CorrespondenceRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    reference_number: str
    direction: CorrespondenceDirection
    subject: str
    sender: str
    recipient: str
    document_date: date
    notes: str | None
    created_at: datetime
